#include "gpio.h"
extern "C"
{
#include "bcm2835.h"
}
using namespace std;
DATA Data;
DATA::GPIO GPIO_data;
DATA::BLINK Blink_data;
DATA::GPIO* gpio_data = &GPIO_data;
DATA::BLINK* blink_data = &Blink_data;
DATA::BLINK* pointers[27];
void GPIO_FUNC(uint8_t gpio, string function)
{
    if (function == "out" || function == "OUT")
    {
        bcm2835_gpio_fsel(gpio, BCM2835_GPIO_FSEL_OUTP);
        gpio_data->pins[gpio_data->used][gpio] = 1;
    }
    if (function == "in" || function == "IN")
    {
        bcm2835_gpio_fsel(gpio, BCM2835_GPIO_FSEL_INPT);
        gpio_data->pins[gpio_data->used][gpio] = 1;
    }
}
void GPIO_ON(uint8_t gpio)
{
    bcm2835_gpio_write(gpio, HIGH);
    gpio_data->pins[gpio_data->write][gpio] = 1;
}
void GPIO_OFF(uint8_t gpio)
{
    bcm2835_gpio_write(gpio, LOW);
    gpio_data->pins[gpio_data->write][gpio] = 0;
}
void READ_GPIO(uint8_t gpio, int &value)
{
    value = bcm2835_gpio_lev(gpio);
    gpio_data->pins[gpio_data->read][gpio] = value;
}
void BLINK(DATA::BLINK data){
    if(data.gpio >= 0 && data.gpio < 27){
        gpio_data->pins[gpio_data->turn_on_delay][data.gpio] = data.turn_on_delay;
        gpio_data->pins[gpio_data->turn_off_delay][data.gpio] = data.turn_off_delay;
        pointers[data.gpio] = &data;
        while(data.terminate_thread == false){
            gpio_data->pins[gpio_data->blink][data.gpio] = 1;
            GPIO_ON(data.gpio);
            this_thread::sleep_for(chrono::milliseconds(data.turn_on_delay));
            GPIO_OFF(data.gpio);         
            this_thread::sleep_for(chrono::milliseconds(data.turn_off_delay));
        }
        gpio_data->pins[gpio_data->blink][data.gpio] = 0;
    }
}
