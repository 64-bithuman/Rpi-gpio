
#include <fstream>
#include <string>
#include <thread>
#include <iostream>
#ifndef GPIO_H
#define GPIO_H
struct DATA
{
    struct GPIO
    {
        int gpio;
        const int read = 2, write = 3, blink = 4, used = 1, turn_on_delay = 5, turn_off_delay = 6;
        int pins[9][27] = {{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                            11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26},
                           {0}, {0}, {0}, {0}, {0}, {0}, {0}, {0}};
    };
    struct BLINK
    {
        int gpio, turn_on_delay, turn_off_delay;
        bool terminate_thread = false;
    };
};
extern DATA Data;
extern DATA::GPIO GPIO_data;
extern DATA::BLINK Blink_data;
extern DATA::GPIO* gpio_data;
extern DATA::BLINK* blink_data;
extern DATA::BLINK* pointers[27];
//static uint8_t index_u;
//static bool first_time = true;
void BLINK(DATA::BLINK data);
void GPIO_FUNC(uint8_t gpio, std::string function);
void GPIO_ON(uint8_t gpio);
void GPIO_OFF(uint8_t gpio);
void READ_GPIO(uint8_t gpio, int &value);
#endif